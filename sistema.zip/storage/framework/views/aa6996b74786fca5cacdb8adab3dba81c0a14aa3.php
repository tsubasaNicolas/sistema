<?php $__env->startSection('content'); ?>

<div class="container">

<?php if(Session::has('Mensaje')): ?>

<div class="alert alert-success" role="alert">
    <?php echo e(Session::get('Mensaje')); ?>

</div>


<?php endif; ?>


<a href="<?php echo e(url('empleados/create')); ?>" class="btn btn-success">Agregar Empleado</a>
<br><br>

<table class='table table-light table-hover table-responsive'>
    <thead class="thead-light">
      <tr>
        <th>#</th>
        <th>Foto</th>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Acciones</th>
    </tr>  
    </thead>
    
    <tbody>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td>
        
    <img src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" class="img-thumbnail img-fluid" alt="" width="100">
        
        </td>
        <td><?php echo e($empleado->Nombre); ?> <?php echo e($empleado->ApellidoPaterno); ?> <?php echo e($empleado->ApellidoMaterno); ?></td>
     
        <td><?php echo e($empleado->Correo); ?></td>
        <td>
            
        <a href="<?php echo e(url('/empleados/'.$empleado->id.'/edit')); ?>" class="btn btn-warning">
        Editar
        </a> 


        <form action="<?php echo e(url('/empleados/'.$empleado->id)); ?>"  method="post" style="display:inline">
        <?php echo e(csrf_field()); ?>


        <?php echo e(method_field('DELETE')); ?>


        <button onclick="return confirm('¿Borrar?');" class="btn btn-danger" type="submit">Borrar</button>
        
        </form>
        </td>
        </tr>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>

</table>

<?php echo e($empleados->links()); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2020\htdocs\laravel\sistema\resources\views/empleados/index.blade.php ENDPATH**/ ?>