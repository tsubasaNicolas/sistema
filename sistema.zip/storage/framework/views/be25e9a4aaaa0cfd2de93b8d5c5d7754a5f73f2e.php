
<div class="form-group">


    <label class="control-label" for="Nombre"><?php echo e('Nombre'); ?></label>

<input type="text" class="form-control <?php echo e($errors->has('Nombre')?'is-invalid':''); ?>" 
name="Nombre" 
id="Nombre"
    value="<?php echo e(isset($empleado->Nombre)?$empleado->Nombre:old('Nombre')); ?>">
    <?php echo $errors->first('Nombre', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label class="control-label" for="ApellidoPaterno"><?php echo e('Apellido Paterno'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('ApellidoPaterno')?'is-invalid':''); ?>" 
name="ApellidoPaterno" 
id="ApellidoPaterno"
value="<?php echo e(isset($empleado->ApellidoPaterno)?$empleado->ApellidoPaterno:old('ApellidoPaterno')); ?>">
<?php echo $errors->first('ApellidoPaterno', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label class="control-label" for="ApellidoMaterno"><?php echo e('Apellido Materno'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('ApellidoMaterno')?'is-invalid':''); ?>" 
name="ApellidoMaterno" 
id="Apellido Materno" 
value="<?php echo e(isset($empleado->ApellidoMaterno)?$empleado->ApellidoMaterno:old('ApellidoMaterno')); ?>">
<?php echo $errors->first('ApellidoMaterno', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label class="control-label" for="Correo"><?php echo e('Correo'); ?></label>
<input type="email" class="form-control <?php echo e($errors->has('Correo')?'is-invalid':''); ?>" 
name="Correo" 
id="Correo"
value="<?php echo e(isset($empleado->Correo)?$empleado->Correo:old('Correo')); ?>">
<?php echo $errors->first('Correo', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="Foto" class="control-label"><?php echo e('Foto'); ?></label>

<?php if(isset($empleado->Foto)): ?>
<img src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" class="img-thumbnail img-fluid" alt="" width="200">
<?php endif; ?>


<input type="file" class="form-control <?php echo e($errors->has('Foto')?'is-invalid':''); ?>" name="Foto" id="Foto" value="">
<?php echo $errors->first('Foto', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<input type="submit" class="btn btn-success" value="<?php echo e($Modo=='crear' ? 'Agregar' : 'Modificar'); ?>">

<a href="<?php echo e(url('empleados')); ?>" class="btn btn-primary">Regresar</a><?php /**PATH C:\xampp2020\htdocs\laravel\sistema\resources\views/empleados/form.blade.php ENDPATH**/ ?>